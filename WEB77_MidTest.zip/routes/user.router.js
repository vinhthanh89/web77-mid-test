import express from "express";
import { deleteUser, getUser, login, signUp } from "../controller/user.controller.js";

const router = express.Router()

router.post("/create-user" , signUp);
router.post("/login" , login);
router.get("/:name" , getUser);
router.delete("/:name" , deleteUser);

export default userRouter